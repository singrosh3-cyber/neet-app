# NEET app
1. Is poore folder ko GitHub repo me upload kar.
2. Repo > Actions > "Build APK" chalne de (5-10 min).
3. Run ke andar Artifacts se NEET-apk download kar, zip khol ke app-debug.apk install kar.
4. App kholke Accessibility aur Overlay permission de.
