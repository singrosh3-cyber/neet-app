package com.neet.focus

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.parseColor("#0E1A22"))
        }
        root.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo) })
        root.addView(TextView(this).apply {
            text = "NEET"; textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "AIIMS ka sapna, padhai ka kaam 🩺\n\nPehle neeche ke 2 step kar. Phir YouTube Shorts, Instagram, Free Fire ya Chrome 20 minute chalane pe app tujhe bahar nikal ke popup dikhayega."
            setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, pad, 0, pad)
        })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("1. Accessibility service ON kar") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. Overlay permission de") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("Popup test kar") { startActivity(Intent(this, PopupActivity::class.java)) }
        setContentView(root)
    }
}
