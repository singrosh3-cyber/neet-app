package com.neet.focus

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class PopupActivity : Activity() {
    private fun mkLines(doing: String) = listOf(
        "Navodaya me kya bola tha? Pura syllabus khatam karega!",
        "Par tu to yahan $doing.",
        "Apni padhai nahi kar raha.",
        "Chal ja, padhai kar. Tab hi AIIMS milega.",
        "Tere dist me tujhe kya bolte hain? Padhe-likhe raat bhar! 😤",
        "Aise AIIMS nahi milega. Uske liye padhai karni padegi."
    )
    private val mot = listOf(
        "Aaj ka 1 ghanta, kal ka white coat 🥼",
        "AIIMS ki seat reel se nahi, mehnat se milti hai.",
        "Abhi dukh utha, baad me Dr. likhna.",
        "Ek chapter aur, bas ek chapter."
    )
    private val memes = listOf(
        Triple("BHAI SYLLABUS KHATAM?", "🤡", "REEL: ARRE NAHI RUK"),
        Triple("AIIMS SEAT:", "😭", "MUJHE BHI TO DEKH LE"),
        Triple("TU: 5 MIN REEL", "⏳", "GHADI: 2 GHANTE 💀")
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val lines = mkLines(intent.getStringExtra("doing") ?: "reel dekh raha hai")
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        val dp = resources.displayMetrics.density
        val pad = (20 * dp).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#0B0F14")); setPadding(pad, pad * 2, pad, pad * 2)
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0B0F14")); addView(root) })

        fun tv(t: String, sp: Float, c: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(c); gravity = Gravity.CENTER; alpha = 0f
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, (10 * dp).toInt(), 0, (10 * dp).toInt())
            root.addView(this)
        }
        val head = tv("⏰ 20 MINUTE HO GAYE", 14f, Color.parseColor("#FF5A64"), true); head.alpha = 1f

        lines.forEachIndexed { i, l ->
            val big = i == 3 || i == 5
            tv(l, 20f, if (big) Color.parseColor("#FFD24A") else Color.WHITE, big)
                .animate().alpha(1f).setStartDelay(i * 1400L).setDuration(500).start()
        }
        val after = lines.size * 1400L

        val m = memes.random()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; alpha = 0f
            background = GradientDrawable().apply { setColor(Color.parseColor("#222222")); cornerRadius = 12 * dp }
            setPadding(pad, pad, pad, pad)
        }
        fun mt(t: String, sp: Float) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD); box.addView(this)
        }
        mt(m.first, 22f); mt(m.second, 80f); mt(m.third, 20f)
        root.addView(box)
        box.animate().alpha(1f).setStartDelay(after).setDuration(600).start()

        tv(mot.random(), 18f, Color.parseColor("#7FF0C8"), true)
            .animate().alpha(1f).setStartDelay(after + 900).setDuration(600).start()

        val btn = Button(this).apply {
            text = "📚 Sorry, ab padhta hun"; alpha = 0f
            setOnClickListener { finish() }
        }
        root.addView(btn)
        btn.animate().alpha(1f).setStartDelay(after + 900).setDuration(600).start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* back se bachna nahi, button daba */ }
}
