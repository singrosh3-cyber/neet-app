package com.neet.focus

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent

class ShortsService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var pkg = ""                       // abhi screen pe kaunsa app hai
    private val secs = HashMap<String, Int>()  // har app ka alag timer

    private val yt = "com.google.android.youtube"
    // package -> (timer ka naam, popup me kya likha jayega)
    private val apps = mapOf(
        "com.instagram.android" to ("insta" to "Instagram chala raha hai"),
        "com.dts.freefireth" to ("ff" to "Free Fire khel raha hai"),
        "com.dts.freefiremax" to ("ff" to "Free Fire khel raha hai"),
        "com.android.chrome" to ("chrome" to "Chrome me time barbaad kar raha hai")
    )

    private val loop = object : Runnable {
        override fun run() {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isInteractive) {
                var key: String? = null
                var doing = ""
                if (pkg == yt) {
                    if (onShorts()) { key = "yt"; doing = "reel dekh raha hai" }
                } else {
                    val a = apps[pkg]
                    if (a != null) { key = a.first; doing = a.second }
                }
                if (key != null) {
                    val n = (secs[key] ?: 0) + 1
                    if (n >= LIMIT) { secs[key] = 0; fire(doing) } else secs[key] = n
                }
            }
            h.postDelayed(this, 1000)
        }
    }

    companion object { const val LIMIT = 20 * 60 } // 20 minute (seconds me)

    override fun onServiceConnected() { h.post(loop) }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = e.packageName?.toString() ?: return
        if (p == "com.android.systemui" || p.contains("inputmethod") ||
            p.contains("keyboard") || p.contains("honeyboard")) return
        pkg = p
    }

    override fun onInterrupt() {}
    override fun onDestroy() { h.removeCallbacks(loop); super.onDestroy() }

    // YouTube me Shorts tab maana jata hai jab ye view IDs dikhein
    private fun onShorts(): Boolean {
        val r = rootInActiveWindow ?: return false
        if (r.packageName?.toString() != yt) return false
        val ids = listOf("reel_recycler", "reel_player_page_container", "reel_watch_player")
        return ids.any { r.findAccessibilityNodeInfosByViewId("$yt:id/$it").isNotEmpty() }
    }

    private fun fire(doing: String) {
        performGlobalAction(GLOBAL_ACTION_HOME)
        h.postDelayed({
            startActivity(Intent(this, PopupActivity::class.java)
                .putExtra("doing", doing).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, 500)
    }
}
